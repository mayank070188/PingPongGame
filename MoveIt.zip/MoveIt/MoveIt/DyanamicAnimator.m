//
//  DyanamicAnimator.m
//  MoveIt
//
//  Created by Intelliswift on 23/07/14.
//  Copyright (c) 2014 Intelliswift. All rights reserved.
//

#import "DyanamicAnimator.h"

@implementation DyanamicAnimator

-(instancetype)initWithReferenceView:(UIView *)view
{
    if (self ==[super initWithReferenceView:view]) {
        
    }
    return self;
}

@end
