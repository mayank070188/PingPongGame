//
//  LevelFinishedVC.h
//  MoveIt
//
//  Created by Intelliswift on 18/07/14.
//  Copyright (c) 2014 Intelliswift. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol levelData <NSObject>

- (int)ballCountValue : (int)value;


@end

@interface LevelFinishedVC : UIViewController <levelData>
{
    
}
@property (weak, nonatomic) IBOutlet UIImageView *bgView;
@property (strong, nonatomic) UIImage *bgImageView;
@property (weak, nonatomic) IBOutlet UIImageView *transparentBG;
@property(nonatomic, strong) NSString* time;
@property (weak, nonatomic) IBOutlet UIView *infoView;
@property (weak, nonatomic) IBOutlet UIView *containerView;
@property (weak, nonatomic) IBOutlet UILabel *labelTimeTaken;
@property (strong ,nonatomic) id <levelData> delegate;
@property (nonatomic) int balls;

- (IBAction)playAgainButton:(id)sender;

- (IBAction)nextLevelButton:(id)sender;
- (IBAction)menuButton:(id)sender;

@end
