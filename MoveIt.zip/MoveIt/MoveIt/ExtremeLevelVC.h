//
//  ExtremeLevelVC.h
//  MoveIt
//
//  Created by Intelliswift on 23/07/14.
//  Copyright (c) 2014 Intelliswift. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LevelFinishedVC.h"

@interface ExtremeLevelVC : UIViewController<levelData>

{
    NSTimer *timerForUpperBar;
    NSTimer *timerForLowerBar;
}

@property (weak, nonatomic) IBOutlet UIImageView *transparentBG;

@property (weak, nonatomic) IBOutlet UIView *containerView;

@property (weak, nonatomic) IBOutlet UIView *upperLeftBar;

@property (weak, nonatomic) IBOutlet UIView *upperRightBar;

@property (weak, nonatomic) IBOutlet UIView *lowerLeftBar;

@property (weak, nonatomic) IBOutlet UIView *lowerRightBar;

@property (weak, nonatomic) IBOutlet UIView *upperLeftView;

@property (weak, nonatomic) IBOutlet UIView *upperRightView;

@property (weak, nonatomic) IBOutlet UIView *lowerRightView;

@property (weak, nonatomic) IBOutlet UIView *middleLeftView;

@property (weak, nonatomic) IBOutlet UIView *middleRightView;

@property (weak, nonatomic) IBOutlet UIView *topView;

@property (weak, nonatomic) IBOutlet UIView *bottomView;

@property (weak, nonatomic) IBOutlet UIView *lowerLeftView;

@property (weak, nonatomic) IBOutlet UIView *greenBackGroundView;

@property (nonatomic) int ballCount;

@property (weak, nonatomic) IBOutlet UIView *upperHiddenBar;

@property (weak, nonatomic) IBOutlet UIView *lowerHiddenBar;

@property (nonatomic) BOOL pushFromHomeVC;

@property (weak, nonatomic) IBOutlet UIView *pauseView;

- (IBAction)resumeButton:(id)sender;

- (IBAction)soundButton:(id)sender;

- (IBAction)menuButton:(id)sender;

@end
