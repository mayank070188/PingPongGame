//
//  HomeScreen.h
//  MoveIt
//
//  Created by Intelliswift on 18/07/14.
//  Copyright (c) 2014 Intelliswift. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AnimationVC.h"
#import "ExtremeLevelVC.h"

@interface HomeScreen : UIViewController

@property (strong, nonatomic) AnimationVC *animationController;
@property (strong,nonatomic) ExtremeLevelVC *xtremeLevel;

- (IBAction)level1Button:(id)sender;
- (IBAction)level2Button:(id)sender;
- (IBAction)level3Button:(id)sender;
- (IBAction)extremeLevel:(id)sender;

@end
