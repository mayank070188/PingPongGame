//
//  AnimationVC.m
//  MoveIt
//
//  Created by Intelliswift on 17/07/14.
//  Copyright (c) 2014 Intelliswift. All rights reserved.
//

#import "AnimationVC.h"
#import <AVFoundation/AVFoundation.h>
#import "AGAppDelegate.h"

@interface AnimationVC () <AVAudioPlayerDelegate,UIAlertViewDelegate>
{
    
    NSMutableArray *array;
    UIAlertView *alert;
    LevelFinishedVC *levelVC;
    NSDate *startTime; // start time of game
    NSDate *endTime;  // end time of game
    BOOL checkRed;
    BOOL isGameFinished; // check game is finished or not.
    UIAlertView *alertView;
    NSTimeInterval secs;
    
}

@property (strong, nonatomic) AVAudioPlayer *audioPlayer;
@property (strong, nonatomic) UIDynamicAnimator *animator;// animator to animate all behavoiur
@property (strong, nonatomic) UICollisionBehavior *collision; // for collision.
@property (strong, nonatomic) UIDynamicItemBehavior *ballDynamicProperties;// for individual item behaviour
@property (strong, nonatomic) UIDynamicItemBehavior *paddleDynamicProperties;// item behaviour for bar.
@property (weak, nonatomic) IBOutlet UIView *containerView; // container view in which game will run.
@property (strong, nonatomic) UIImageView *bouncingCircle; // circle view as uiview
@property (nonatomic) CGFloat xVelo;
@property (nonatomic) CGFloat yVelo;
@property(nonatomic, weak) NSTimer *timer;
@property (nonatomic) CGPoint leftPadCenter;
@property (nonatomic) CGPoint rightPadCenter;
@property (weak, nonatomic) IBOutlet UIView *leftPadView; // leftbar
@property (weak, nonatomic) IBOutlet UIView *rightPadView; // right bar
@property (nonatomic, strong) UIPushBehavior *pusher; // push or velocity to balls
@property (weak, nonatomic) IBOutlet UIView *firstBoundaryView;// boundary items
@property (weak, nonatomic) IBOutlet UIView *secondBoundaryView;// boundary items
@property (weak, nonatomic) IBOutlet UIView *thirdBoundaryView;// boundary items
@property (weak, nonatomic) IBOutlet UIView *fourthBoundaryView;// boundary items
@property (weak, nonatomic) IBOutlet UIView *lowerfirstBoundaryView;// boundary items
@property (weak, nonatomic) IBOutlet UIView *lowersecondBoundaryView;// boundary items

@end

@implementation AnimationVC

-(int)ballCountValue:(int)value
{
    _ballCount = value;
    return _ballCount;
}

- (void)pauseGame
{
    [self stopGame];
}

-(void)resumeGame
{
    [self initBehaviors];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(pauseGame)
                                                name:UIApplicationWillResignActiveNotification
                                              object:nil];
    
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(resumeGame)
                                                name:UIApplicationDidBecomeActiveNotification
                                              object:nil];
    
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.enabled = NO;
        
    }
    
    levelVC = [[LevelFinishedVC alloc] initWithNibName:@"LevelFinishedVC" bundle:nil];
    levelVC.delegate = self;
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapGesture:)];
    tapGesture.numberOfTapsRequired = 2;
    [self.view addGestureRecognizer:tapGesture];
    
    NSURL *url = [NSURL fileURLWithPath:[[NSBundle mainBundle]
                                         pathForResource:@"ping_pong"
                                         ofType:@"mp3"]];
    
    NSError *error;
    _audioPlayer = [[AVAudioPlayer alloc]
                    initWithContentsOfURL:url
                    error:&error];
    if (error)
    {
        NSLog(@"Error in audioPlayer: %@",
              [error localizedDescription]);
    } else {
        _audioPlayer.delegate = self;
        [_audioPlayer prepareToPlay];
    }
    
    alert = [[UIAlertView alloc] initWithTitle:@"Congratulation" message:@"Level Complete" delegate:nil cancelButtonTitle:@"Thanks" otherButtonTitles:nil];
    
}

- (void)initWithBallViewFrame
{
    CGFloat vWidthRed = _containerView.frame.size.width - 100;
    CGFloat vHeightRed = _containerView.frame.size.height - 100;
    
    
    for (int i = 0; i < _ballCount; i++) {
        
        self.bouncingCircle = [[UIImageView alloc] initWithFrame:CGRectMake(arc4random() % (int)roundf(vWidthRed),arc4random() % (int)roundf(vHeightRed), 15, 15)];
        
        UIColor *color;
        if (i % 2) {
            //color   = [UIColor colorWithRed:0 green:0 blue:1 alpha:1];
            _bouncingCircle.tag = 2;
            _bouncingCircle.image = [UIImage imageNamed:@"blue-ball.png"];
        }
        else{
            //color = [UIColor colorWithRed:1 green:0 blue:0 alpha:1];
            _bouncingCircle.tag = 3;
            _bouncingCircle.image = [UIImage imageNamed:@"red-ball.png"];
        }
        
        [_bouncingCircle setBackgroundColor:color];
        _bouncingCircle.layer.cornerRadius = 7.5;
        _bouncingCircle.layer.borderColor = [UIColor blackColor].CGColor;
        _bouncingCircle.layer.borderWidth = 0.0;
        
        // Applying shadow....
        _bouncingCircle.layer.shadowOffset = CGSizeMake(2.0, 5.0);
        _bouncingCircle.layer.shadowOpacity = 0.5;
        [self.containerView addSubview:self.bouncingCircle];
        [array addObject:self.bouncingCircle];
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
        self.navigationController.navigationBar.hidden = YES;
    _leftPadView.hidden = NO;
    [_audioPlayer play];
    [AGAppDelegate shared].gcdStatus = NO;
     array = [[NSMutableArray alloc] init];
     checkRed = NO;
     isGameFinished = NO;
    
    [self initWithBallViewFrame];
    
    self.leftPadCenter = self.leftPadView.center;
    self.rightPadCenter = self.rightPadView.center;
//    self.leftPadView.layer.shadowOffset = CGSizeMake(5.0, 8.0);
//    self.leftPadView.layer.shadowOpacity = 0.5;
//    self.rightPadView.layer.shadowOffset = CGSizeMake(5.0, 8.0);
//    self.rightPadView.layer.shadowOpacity = 0.5;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self initBehaviors];
    
    //Start an activity indicator here
    
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        startTime = [NSDate date];

        while (![AGAppDelegate shared].gcdStatus)
        {
             if (!isGameFinished  )
               {
                [self checkBallPosition];
               }
        }
        //Call your function or whatever work that needs to be done
        //Code in this part is run on a background thread
        
        dispatch_async(dispatch_get_main_queue(), ^(void) {
            
            if (isGameFinished)
            {
            levelVC.balls = _ballCount;
            
           
            NSLog(@"Seconds --------> %f", secs);
            
            int second = (int)secs % 60;
            
            int minutes = ((int)secs / 60) % 60;
            
            int hours = (int)secs / 3600;
            
            NSString *time = [NSString stringWithFormat:@"%d:%02d:%02d ",hours,minutes,second];
            levelVC.time = time;
            
            levelVC.bgImageView = [self convertImageWithView:self.view];
                
            [self.navigationController pushViewController:levelVC animated:YES];
            //Stop your activity indicator or anything else with the GUI
            //Code here is run on the main thread
        }
        });
    });
    
    
}

- (void)checkBallPosition
{
    CGFloat yValue = _containerView.center.y ;
    NSLog(@"y = %f",_containerView.center.y );
    int countRed = 0;
    int countBlue = 0;
    //BOOL checkRed = NO;
   // BOOL isGameFinished = NO;
    NSArray *tempArray = [array copy];
    
    for (UIView *ball in tempArray) {
     
        if (ball.tag == 2 && !checkRed) {
            if (ball.center.y > yValue + 20) {
                countBlue ++;
                if (countBlue == tempArray.count/2) {
                    checkRed = YES;
                }
            }
            else
            {
                countBlue = 0;
                break;
            }
        }
        else if (ball.tag == 3 && checkRed)
        {
            if (ball.center.y < yValue - 20) {
                countRed ++;
                if (countRed == tempArray.count/2 )
                {
                    endTime = [NSDate date];
                    secs = [endTime timeIntervalSinceDate:startTime];
                    if(secs < 1.0)
                    {
                        [self initBehaviors];
                       
                    }
                    else
                    {
                    isGameFinished = YES;
                    [AGAppDelegate shared].gcdStatus = YES;
                    [self stopGame];
                   
                    NSLog(@"Game Finished");
                    }
                    break;
                }
            }
            else
            {
                countRed = 0;
                countBlue = 0;
                checkRed = NO;
                break;
            }
        }
    }
  
}



- (void)initBehaviors
{
    self.animator = [[UIDynamicAnimator alloc] initWithReferenceView:self.containerView];
    
    CGFloat pushDirection = 0.02;
    if (_ballCount == 10) {
        pushDirection = 0.020;
    }
    // Start ball off with a push
    self.pusher = [[UIPushBehavior alloc] initWithItems:array
                                                   mode:UIPushBehaviorModeInstantaneous];
    self.pusher.pushDirection = CGVectorMake(pushDirection, pushDirection);
    
    self.pusher.active = YES; // Because push is instantaneous, it will only happen once
    [self.animator addBehavior:self.pusher];
    
    // Step 1: Add collisions
    self.collision = [[UICollisionBehavior alloc] initWithItems:array];
    [_collision addItem:self.leftPadView];
    [_collision addItem:self.rightPadView];
    [_collision addItem:self.firstBoundaryView];
    [_collision addItem:self.secondBoundaryView];
    [_collision addItem:self.thirdBoundaryView];
    [_collision addItem:self.fourthBoundaryView];
    [_collision addItem:self.lowerfirstBoundaryView];
    [_collision addItem:self.lowersecondBoundaryView];
    _collision.collisionDelegate = self;
    _collision.collisionMode = UICollisionBehaviorModeItems;
    _collision.translatesReferenceBoundsIntoBoundary = YES;
    [self.animator addBehavior:_collision];
    
    // Step 2: Remove rotation
    self.ballDynamicProperties = [[UIDynamicItemBehavior alloc]
                                  initWithItems:array];
    self.ballDynamicProperties.allowsRotation = NO;
    [self.animator addBehavior:self.ballDynamicProperties];
    
    self.paddleDynamicProperties = [[UIDynamicItemBehavior alloc]
                                    initWithItems:@[self.leftPadView,self.rightPadView,self.firstBoundaryView,self.secondBoundaryView,self.thirdBoundaryView,self.fourthBoundaryView,self.lowerfirstBoundaryView,self.lowersecondBoundaryView]];
    self.paddleDynamicProperties.allowsRotation = NO;
    [self.animator addBehavior:self.paddleDynamicProperties];
    
    // Step 3: Heavy paddle
    self.paddleDynamicProperties.density = 1000000.0f;
    
    // Step 4: Better collisions, no friction
    //[self.ballDynamicProperties addAngularVelocity:5.0 forItem:_bouncingCircle];
    self.ballDynamicProperties.elasticity = 1.0;
    self.ballDynamicProperties.friction = 0.0;
    self.ballDynamicProperties.resistance = 0.0;
    
    
}

-(void)viewWillDisappear:(BOOL)animated
{
    //self.navigationController.navigationBar.hidden = NO;
    [AGAppDelegate shared].gcdStatus = YES;
    _leftPadView.hidden = YES;
}


- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [_audioPlayer stop];
    
    
    [self stopGame];
    
    for (UIView *view in self.containerView.subviews) {
        if (view.tag == 2 || view.tag == 3) {
            [view removeFromSuperview];
            //NSLog(@"%i",view.tag);
        }
    }
    
}

- (void)handleTapGesture:(UITapGestureRecognizer *)sender {
    if (sender.state == UIGestureRecognizerStateRecognized) {

        //isGameFinished = YES;
        _pauseView.hidden = NO;
        _transparentBG.hidden = NO;
        [_containerView bringSubviewToFront:_pauseView];
        
        [self stopGame];
        

        
    }
    
    
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 2) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else
    if (buttonIndex == 0) {
        [self initBehaviors];
    }
    else
        
    if (_audioPlayer.playing) {
        [_audioPlayer stop];
        [self initBehaviors];
    }
    else
        [_audioPlayer play];
        [self initBehaviors];
    
    }


- (UIImage *) convertImageWithView:(UIView *)view
{
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, NO, 0.0);
    //UIGraphicsBeginImageContext(self.view.bounds.size);
    [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage * img = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return img;
}



#pragma mark - Touch Events

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    //   UITouch *touch = [touches anyObject];
    
}


-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    
    UITouch *touch = [touches anyObject];
    
    CGPoint currentTouchLocation = [touch locationInView:self.containerView];
    CGPoint previousTouchLocation = [touch previousLocationInView:self.containerView];

    
    if (self.rightPadView.frame.origin.x > self.containerView.frame.size.width )
    {
        currentTouchLocation = previousTouchLocation;
    }
    
    if (self.rightPadView.frame.origin.x < 50 )
    {
        currentTouchLocation.x = (currentTouchLocation.x + 50);
    }
    
    
    if (currentTouchLocation.x > previousTouchLocation.x) {
        //NSLog(@"Right");
        
        CGFloat yPt = self.rightPadView.center.y;
        CGFloat x1Pt = self.rightPadView.center.x +7;
        CGFloat x2Pt = self.leftPadView.center.x +7;
        
        
        CGPoint rPadCenter = CGPointMake(x1Pt,yPt);
        CGPoint lPadCenter = CGPointMake(x2Pt,yPt);
        
       // NSLog(@"self.rightPadView.center.x = %f  y = %f ",self.rightPadView.center.x,self.rightPadView.center.y);
        
        self.rightPadView.center = rPadCenter;
        self.leftPadView.center = lPadCenter;
    }
    else
    {
        //NSLog(@"Left");
        
        CGFloat yPt = self.rightPadView.center.y;
        CGFloat x1Pt = self.rightPadView.center.x -4;
        CGFloat x2Pt = self.leftPadView.center.x -4;
        
        CGPoint rPadCenter = CGPointMake(x1Pt,yPt);
        CGPoint lPadCenter = CGPointMake(x2Pt,yPt);
        
        self.rightPadView.center = rPadCenter;
        self.leftPadView.center = lPadCenter;
    }
    
    
    [_animator updateItemUsingCurrentState:self.leftPadView];
    [_animator updateItemUsingCurrentState:self.rightPadView];
}



#pragma mark - UICollisionBehavior Delegate method implementation

-(void)collisionBehavior:(UICollisionBehavior *)behavior beganContactForItem:(id<UIDynamicItem>)item withBoundaryIdentifier:(id<NSCopying>)identifier atPoint:(CGPoint)p{
    
}


-(void)collisionBehavior:(UICollisionBehavior *)behavior endedContactForItem:(id<UIDynamicItem>)item withBoundaryIdentifier:(id<NSCopying>)identifier{
    
    //self.orangeBall.backgroundColor = [UIColor orangeColor];
}


-(void)collisionBehavior:(UICollisionBehavior *)behavior beganContactForItem:(id<UIDynamicItem>)item1 withItem:(id<UIDynamicItem>)item2 atPoint:(CGPoint)p{
    
    //NSLog(@"%f",_lowerfirstBoundaryView.frame.origin.x);
}

#pragma mark - AVAudio Delegate method implementation

-(void)audioPlayerDidFinishPlaying:
(AVAudioPlayer *)player successfully:(BOOL)flag
{
    [_audioPlayer play];
}

-(void)audioPlayerDecodeErrorDidOccur:
(AVAudioPlayer *)player error:(NSError *)error
{
}

-(void)audioPlayerBeginInterruption:(AVAudioPlayer *)player
{
}

-(void)audioPlayerEndInterruption:(AVAudioPlayer *)player
{
}

- (void)stopGame
{
    self.animator = nil;
    self.collision = nil;
    self.pusher = nil;
}

- (IBAction)resumeButton:(id)sender {
    isGameFinished = NO;
    [self initBehaviors];
    _pauseView.hidden = YES;
    _transparentBG.hidden = YES;
}

- (IBAction)soundButton:(id)sender {
    
    isGameFinished = NO;
    if (_audioPlayer.playing) {
        [_audioPlayer stop];
        //[self initBehaviors];
        //_pauseView.hidden = YES;
    }
    else
        [_audioPlayer play];
    
    [self initBehaviors];
    _pauseView.hidden = YES;
    _transparentBG.hidden = YES;
    

}

- (IBAction)menuButton:(id)sender {
    _pauseView.hidden = YES;
    _transparentBG.hidden = YES;
    isGameFinished = NO;
    [self.navigationController popViewControllerAnimated:YES];
}
@end
