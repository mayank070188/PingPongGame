//
//  main.m
//  MoveIt
//
//  Created by Intelliswift on 17/07/14.
//  Copyright (c) 2014 Intelliswift. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AGAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AGAppDelegate class]));
    }
}
