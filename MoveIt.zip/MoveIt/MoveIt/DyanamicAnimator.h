//
//  DyanamicAnimator.h
//  MoveIt
//
//  Created by Intelliswift on 23/07/14.
//  Copyright (c) 2014 Intelliswift. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DyanamicAnimator : UIDynamicAnimator

-(instancetype)initWithReferenceView:(UIView *)view;



@end
