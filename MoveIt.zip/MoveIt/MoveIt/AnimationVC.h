//
//  AnimationVC.h
//  MoveIt
//
//  Created by Intelliswift on 17/07/14.
//  Copyright (c) 2014 Intelliswift. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LevelFinishedVC.h"

@interface AnimationVC : UIViewController<UICollisionBehaviorDelegate,levelData>

@property (nonatomic) int ballCount;
@property (weak, nonatomic) IBOutlet UIView *pauseView;
- (IBAction)resumeButton:(id)sender;
- (IBAction)soundButton:(id)sender;
- (IBAction)menuButton:(id)sender;

@property (weak, nonatomic) IBOutlet UIImageView *transparentBG;

@end
