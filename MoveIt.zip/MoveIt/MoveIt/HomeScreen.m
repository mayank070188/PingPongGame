//
//  HomeScreen.m
//  MoveIt
//
//  Created by Intelliswift on 18/07/14.
//  Copyright (c) 2014 Intelliswift. All rights reserved.
//

#import "HomeScreen.h"

@interface HomeScreen ()

@end

@implementation HomeScreen

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _animationController = [[AnimationVC alloc] initWithNibName:@"AnimationVC" bundle:nil];
    _xtremeLevel = [[ExtremeLevelVC alloc] initWithNibName:@"ExtremeLevelVC" bundle:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)extremeLevel:(id)sender {
    _xtremeLevel.ballCount = 9;
    _xtremeLevel.pushFromHomeVC = YES;
    [self.navigationController pushViewController:_xtremeLevel animated:YES];
}

- (IBAction)level1Button:(id)sender
{
    _animationController.ballCount = 4;
    [self.navigationController pushViewController:_animationController animated:YES];
}

- (IBAction)level2Button:(id)sender {
    _animationController.ballCount = 6;
    [self.navigationController pushViewController:_animationController animated:YES];
}

- (IBAction)level3Button:(id)sender {
    _animationController.ballCount = 8;
    [self.navigationController pushViewController:_animationController animated:YES];
}


@end
