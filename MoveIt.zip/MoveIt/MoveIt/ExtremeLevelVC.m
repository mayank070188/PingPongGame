//
//  ExtremeLevelVC.m
//  MoveIt
//
//  Created by Intelliswift on 23/07/14.
//  Copyright (c) 2014 Intelliswift. All rights reserved.
//

#import "ExtremeLevelVC.h"
#import <AVFoundation/AVFoundation.h>
#import "AGAppDelegate.h"

static int LongPressConstant = 4;

@interface ExtremeLevelVC ()<AVAudioPlayerDelegate,UIAlertViewDelegate,UICollisionBehaviorDelegate>
{
    
    NSMutableArray *array;
    UIAlertView *alert;
    LevelFinishedVC *levelVC;
    NSDate *startTime;
    NSDate *endTime;
    BOOL checkRed;
    BOOL checkGreen;
    BOOL checkBlue;
    BOOL isGameFinished;
    BOOL longPressDetectedStatus;
    UIAlertView *alertView;
    int longPressCount;
    NSTimeInterval secs;
    
}
@property (nonatomic) CGPoint upperLeftBarCenter;
@property (nonatomic) CGPoint upperRightBarCenter;
@property (nonatomic) CGPoint lowerLeftBarCenter;
@property (nonatomic) CGPoint lowerRightBarCenter;

@property (strong, nonatomic) AVAudioPlayer *audioPlayer;
@property (strong, nonatomic) UIDynamicAnimator *animator;
@property (strong, nonatomic) UICollisionBehavior *collision;
@property (strong, nonatomic) UIDynamicItemBehavior *ballDynamicProperties;
@property (strong, nonatomic) UIDynamicItemBehavior *paddleDynamicProperties;
@property (nonatomic, strong) UIPushBehavior *pusher;

@property (strong, nonatomic) UIImageView *bouncingCircle;


@end

@implementation ExtremeLevelVC

-(int)ballCountValue:(int)value
{
    _ballCount = value;
    return _ballCount;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    }
   
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapGesture:)];
    tapGesture.numberOfTapsRequired = 2;
    [self.view addGestureRecognizer:tapGesture];
    
    UILongPressGestureRecognizer *longPressRecognizer =
    [[UILongPressGestureRecognizer alloc]
     initWithTarget:self
     action:@selector(longPressDetected:)];
    longPressRecognizer.minimumPressDuration = 1;
    longPressRecognizer.numberOfTouchesRequired = 1;
    [self.containerView addGestureRecognizer:longPressRecognizer];
    
    levelVC = [[LevelFinishedVC alloc] initWithNibName:@"LevelFinishedVC" bundle:nil];
    levelVC.delegate = self;
    
    
    NSURL *url = [NSURL fileURLWithPath:[[NSBundle mainBundle]
                                         pathForResource:@"ping_pong"
                                         ofType:@"mp3"]];
    
    NSError *error;
    _audioPlayer = [[AVAudioPlayer alloc]
                    initWithContentsOfURL:url
                    error:&error];
    if (error)
    {
        NSLog(@"Error in audioPlayer: %@",
              [error localizedDescription]);
    } else {
        _audioPlayer.delegate = self;
        [_audioPlayer prepareToPlay];
    }
    
    alert = [[UIAlertView alloc] initWithTitle:@"Congratulation" message:@"Level Complete" delegate:nil cancelButtonTitle:@"Thanks" otherButtonTitles:nil];
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [AGAppDelegate shared].gcdStatus = NO;
    _lowerLeftBar.hidden = NO;
    _upperLeftBar.hidden = NO;
    self.navigationController.navigationBar.hidden = YES;
    [_audioPlayer play];
    longPressCount = 0;
    _ballCount = 9;
    array = [[NSMutableArray alloc] init];
    checkRed = NO;
    checkGreen = NO;
    checkBlue = YES;
    isGameFinished = NO;
    CGFloat vWidthRed = self.view.frame.size.width - 100;
    CGFloat vHeightRed = self.view.frame.size.height - 100;
    
    
    for (int i = 0; i < _ballCount; i++) {
        
        self.bouncingCircle = [[UIImageView alloc] initWithFrame:CGRectMake(arc4random() % (int)roundf(vWidthRed),arc4random() % (int)roundf(vHeightRed), 15, 15)];
        
        //self.bouncingCircle = [[UIView alloc] initWithFrame:CGRectMake(arc4random_uniform(vWidthRed),arc4random_uniform(vHeightRed), 15, 15)];
        
        
        //_bouncingCircle = [[UIView alloc] initWithFrame:CGRectMake(vWidthRed, vWidthRed, 15, 15)];
        
        
        UIColor *color;
        if (i < _ballCount/3) {
            //color   = [UIColor colorWithRed:1 green:0 blue:0 alpha:1];
            _bouncingCircle.tag = 3;
            _bouncingCircle.image = [UIImage imageNamed:@"red-ball.png"];
        }
        else if(i < _ballCount * 2/3)
        {
            //color = [UIColor colorWithRed:0 green:1 blue:0 alpha:1];
            _bouncingCircle.tag = 5;
            _bouncingCircle.image = [UIImage imageNamed:@"green-ball.png"];
        }
        
        else
        {
            //color = [UIColor colorWithRed:0 green:0 blue:1 alpha:1];
            _bouncingCircle.tag = 2;
            _bouncingCircle.image = [UIImage imageNamed:@"blue-ball.png"];
        }
        
        [_bouncingCircle setBackgroundColor:color];
        _bouncingCircle.layer.cornerRadius = 7.5;
        _bouncingCircle.layer.borderColor = [UIColor blackColor].CGColor;
        _bouncingCircle.layer.borderWidth = 0.0;
        _bouncingCircle.layer.shadowOffset = CGSizeMake(5.0, 8.0);
        _bouncingCircle.layer.shadowOpacity = 0.5;
        [self.containerView addSubview:self.bouncingCircle];
        [array addObject:self.bouncingCircle];
    }
    
    _upperLeftBarCenter = self.upperLeftBar.center;
    _upperRightBarCenter = self.upperRightBar.center;
    _lowerLeftBarCenter = self.lowerLeftBar.center;
    _lowerRightBarCenter = self.lowerRightBar.center;
    
    _upperLeftBar.layer.shadowOffset = CGSizeMake(5.0, 8.0);
    _upperLeftBar.layer.shadowOpacity = 0.5;
    
    _upperRightBar.layer.shadowOffset = CGSizeMake(5.0, 8.0);
    _upperRightBar.layer.shadowOpacity = 0.5;
    
    _lowerLeftBar.layer.shadowOffset = CGSizeMake(5.0, 8.0);
    _lowerLeftBar.layer.shadowOpacity = 0.5;
    
    _lowerRightBar.layer.shadowOffset = CGSizeMake(5.0, 8.0);
    _lowerRightBar.layer.shadowOpacity = 0.5;
    
    _upperHiddenBar.layer.shadowOffset = CGSizeMake(5.0, 8.0);
    _upperHiddenBar.layer.shadowOpacity = 0.5;
    
    _lowerHiddenBar.layer.shadowOffset = CGSizeMake(5.0, 8.0);
    _lowerHiddenBar.layer.shadowOpacity = 0.5;
    
    
    
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self initBehaviors];
    
    //Start an activity indicator here
    
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        startTime = [NSDate date];
        //            self.timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(checkBallPosition)userInfo:nil repeats:YES];
        while (![AGAppDelegate shared].gcdStatus)
        {
            if (!isGameFinished  )
            {
                [self checkBallPosition];
            }
        }
        //Call your function or whatever work that needs to be done
        //Code in this part is run on a background thread
        
        dispatch_async(dispatch_get_main_queue(), ^(void) {
            
            levelVC.balls = _ballCount;
            
            
            
            NSLog(@"Seconds --------> %f", secs);
            
            int sececond = (int)secs % 60;
            
            int minutes = ((int)secs / 60) % 60;
            
            int hours = (int)secs / 3600;
            
            NSString *time = [NSString stringWithFormat:@"%d:%02d:%02d ",hours,minutes,sececond];
            levelVC.time = time;
            levelVC.bgImageView = [self convertImageWithView:self.view];
            if(_pushFromHomeVC)
            {
            [self.navigationController pushViewController:levelVC animated:YES];
                _pushFromHomeVC = NO;
            }else
            {
                levelVC.balls = 0;
                [self.navigationController popViewControllerAnimated:YES];
            }
            //Stop your activity indicator or anything else with the GUI
            //Code here is run on the main thread
            
        });
    });
    
    
}

- (void)checkBallPosition
{
    CGFloat yValueForRed = _containerView.frame.origin.y+ _containerView.frame.size.height/3 - 20 ;
    CGFloat yValueForBlue =   ((_containerView.frame.size.height*2)/3) - 20 +_containerView.frame.origin.y;
    NSLog(@"y = %f",_containerView.center.y );
    NSLog(@"yValueForRed = %f",yValueForRed );
    NSLog(@"yValueForBlue = %f",yValueForBlue );
    int countRed = 0;
    int countBlue = 0;
    int countgreen = 0;
    //BOOL checkRed = NO;
    // BOOL isGameFinished = NO;
    NSArray *tempArray = [array copy];
    
    for (UIView *ball in tempArray) {
        
        if (ball.tag == 2 && checkBlue) {
            if (ball.center.y > yValueForBlue) {
                countBlue ++;
                if (countBlue == tempArray.count/3) {
                    //checkRed = NO;
                    checkGreen = YES;
                    checkBlue = NO;
                }
            }
            else
            {
                checkRed = NO;
                checkGreen = NO;
                countBlue = 0;
                countRed = 0;
                countgreen = 0;
                break;
            }
        }
        else if(ball.tag == 5 && checkGreen)
        {
            if (ball.center.y < yValueForBlue && ball.center.y > yValueForRed) {
                countgreen ++;
                if (countgreen == tempArray.count/3) {
                     checkRed = YES;
                    checkGreen = NO;
                                    }
            }
            else
            {
                countBlue = 0;
                countRed = 0;
                countgreen = 0;
                checkRed = NO;
                checkGreen = NO;
                checkBlue = YES;
                break;
            }

        }
        else if (ball.tag == 3 && checkRed)
        {
            if (ball.center.y < yValueForRed ) {
                countRed ++;
                if (countRed == tempArray.count/3 ) {
                    isGameFinished = YES;
                    [AGAppDelegate shared].gcdStatus = YES;
                    //[alert show];
                    
                    self.animator = nil;
                    self.collision = nil;
                    self.pusher = nil;
                    
                    //[self.navigationController pushViewController:levelVC animated:YES];
                    NSLog(@"Game Finished");
                    endTime = [NSDate date];
                    secs = [endTime timeIntervalSinceDate:startTime];
                    if(secs < 1.0)
                    {
                        [self initBehaviors];
                        isGameFinished = NO;
                        
                    }
                    
                    break;
                }
            }
            else
            {
                countRed = 0;
                countBlue = 0;
                countgreen = 0;
                checkRed = NO;
                checkGreen = NO;
                checkBlue = YES;
                break;
            }
        }
    }
    
}



- (void)initBehaviors
{
    self.animator = [[UIDynamicAnimator alloc] initWithReferenceView:self.containerView];
    
    CGFloat pushDirection = 0.02;
    
    // Start ball off with a push
    self.pusher = [[UIPushBehavior alloc] initWithItems:array
                                                   mode:UIPushBehaviorModeInstantaneous];
    self.pusher.pushDirection = CGVectorMake(pushDirection, pushDirection);
    
    self.pusher.active = YES; // Because push is instantaneous, it will only happen once
    [self.animator addBehavior:self.pusher];
    
    // Step 1: Add collisions
    self.collision = [[UICollisionBehavior alloc] initWithItems:array];
    [_collision addItem:_upperLeftBar];
    [_collision addItem:_upperRightBar];
    [_collision addItem:_lowerLeftBar];
    [_collision addItem:_lowerRightBar];
    [_collision addItem:_upperLeftView];
    [_collision addItem:_upperRightView];
    [_collision addItem:_middleLeftView];
    [_collision addItem:_middleRightView];
    [_collision addItem:_lowerLeftView];
    [_collision addItem:_lowerRightView];
    [_collision addItem:_topView];
    [_collision addItem:_bottomView];
    _collision.collisionDelegate = self;
    _collision.collisionMode = UICollisionBehaviorModeItems;
    _collision.translatesReferenceBoundsIntoBoundary = YES;
    [self.animator addBehavior:_collision];
    
    // Step 2: Remove rotation
    self.ballDynamicProperties = [[UIDynamicItemBehavior alloc]
                                  initWithItems:array];
    self.ballDynamicProperties.allowsRotation = NO;
    [self.animator addBehavior:self.ballDynamicProperties];
    
    self.paddleDynamicProperties = [[UIDynamicItemBehavior alloc]
                                    initWithItems:@[_upperLeftBar,   _upperRightBar,_lowerLeftBar,_lowerRightBar,_upperLeftView,_upperRightView,_middleLeftView,_middleRightView,_lowerLeftView,_lowerRightView,_topView,_bottomView,_upperHiddenBar,_lowerHiddenBar]];
    
    self.paddleDynamicProperties.allowsRotation = NO;
    [self.animator addBehavior:self.paddleDynamicProperties];
    
    // Step 3: Heavy paddle
    self.paddleDynamicProperties.density = 1000000.0f;
    
    // Step 4: Better collisions, no friction
    self.ballDynamicProperties.elasticity = 1.0;
    self.ballDynamicProperties.friction = 0.0;
    self.ballDynamicProperties.resistance = 0.0;
    
    
}

-(void)viewWillDisappear:(BOOL)animated
{
    //self.navigationController.navigationBar.hidden = NO;
    [AGAppDelegate shared].gcdStatus = YES;
    _lowerLeftBar.hidden = YES;
    _upperLeftBar.hidden = YES;
    
    if (_upperHiddenBar.hidden == NO || _lowerHiddenBar.hidden == NO )
    {
    [self timeoutForLowerBar];
    [self timeoutForUpperBar];
    }
}



- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [_audioPlayer stop];
    
    
    self.animator = nil;
    self.collision = nil;
    self.pusher = nil;
    
    for (UIView *view in self.containerView.subviews) {
        if (view.tag == 2 || view.tag == 3 || view.tag == 5) {
            [view removeFromSuperview];
            //NSLog(@"%i",view.tag);
        }
    }
    
}

#pragma mark - Gesture Handeling

- (void)longPressDetected:(UIRotationGestureRecognizer *)recognizer
{
    // Get the location of the gesture
    CGPoint location = [recognizer locationInView:self.view];
    
  if (!longPressDetectedStatus)
  {
      longPressDetectedStatus = YES;
      
      if (location.y < _containerView.center.y)
    {
        [UIView animateWithDuration:0.5 animations:^{
            _upperHiddenBar.hidden = NO;
            _upperLeftBar . hidden = YES;
            _upperRightBar.hidden = YES;
        }];
        
        [_collision removeItem:_upperLeftBar];
        [_collision removeItem:_upperRightBar];
        [_collision addItem:_upperHiddenBar];
        [_animator addBehavior:_collision];
        
        timerForUpperBar = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(timeoutForUpperBar)userInfo:nil repeats:NO];
        
        
    }
    else
    {
        
        [UIView animateWithDuration:0.5 animations:^{
            _lowerHiddenBar.hidden = NO;
            _lowerLeftBar . hidden = YES;
            _lowerRightBar.hidden = YES;
        }];
        
        [_collision removeItem:_lowerLeftBar];
        [_collision removeItem:_lowerRightBar];
        [_collision addItem:_lowerHiddenBar];
        [_animator addBehavior:_collision];
        timerForLowerBar = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(timeoutForLowerBar)userInfo:nil repeats:NO];
            }
       
    }
}

- (void)timeoutForUpperBar
{
    [UIView animateWithDuration:0.5 animations:^{
        _upperHiddenBar.hidden = YES;
        _upperLeftBar . hidden = NO;
        _upperRightBar.hidden = NO;
    }];
    
    [_collision removeItem:_upperHiddenBar];
    [_collision addItem:_upperLeftBar];
    [_collision addItem:_upperRightBar];
    [_animator addBehavior:_collision];
    longPressDetectedStatus = NO;
}

- (void)timeoutForLowerBar
{
    [UIView animateWithDuration:0.5 animations:^{
        _lowerHiddenBar.hidden = YES;
        _lowerLeftBar . hidden = NO;
        _lowerRightBar.hidden = NO;
    }];
    
    [_collision removeItem:_lowerHiddenBar];
    [_collision addItem:_lowerLeftBar];
    [_collision addItem:_lowerRightBar];
    [_animator addBehavior:_collision];
    longPressDetectedStatus = NO;
}

- (void)handleTapGesture:(UITapGestureRecognizer *)sender {
    if (sender.state == UIGestureRecognizerStateRecognized) {
                _pauseView.hidden = NO;
        _transparentBG.hidden = NO;
        [_containerView bringSubviewToFront:_pauseView];
        
        self.animator = nil;
        self.collision = nil;
        self.pusher = nil;
            
    }

    
    
}

#pragma mark - Alert Events

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 2) {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
    else
        if (buttonIndex == 0) {
            [self initBehaviors];
        }
        else
            
            if (_audioPlayer.playing) {
                [_audioPlayer stop];
                [self initBehaviors];
            }
            else
                [_audioPlayer play];
    [self initBehaviors];
    
}



#pragma mark - Touch Events

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    //   UITouch *touch = [touches anyObject];
    
}


-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    
    UITouch *touch = [touches anyObject];
    
    CGPoint currentTouchLocation = [touch locationInView:self.containerView];
    CGPoint previousTouchLocation = [touch previousLocationInView:self.containerView];
    //
    //    NSLog(@"CurrentTouchLocation = %f - %f",currentTouchLocation.x,currentTouchLocation.y);
    //    NSLog(@"PreviousTouchLocation = %f - %f",previousTouchLocation.x,previousTouchLocation.y);
    
    if (currentTouchLocation.y < _containerView.center.y) {
        if (self.upperRightBar.frame.origin.x > self.containerView.frame.size.width )
        {
            currentTouchLocation = previousTouchLocation;
        }
        
        if (self.upperRightBar.frame.origin.x < 50 )
        {
            currentTouchLocation.x = (currentTouchLocation.x + 50);
        }
        
        
        if (currentTouchLocation.x > previousTouchLocation.x) {
            //NSLog(@"Right");
            
            CGFloat yPt = self.upperRightBar.center.y;
            CGFloat x1Pt = self.upperRightBar.center.x +7;
            CGFloat x2Pt = self.upperLeftBar.center.x +7;
            
            
            CGPoint rPadCenter = CGPointMake(x1Pt,yPt);
            CGPoint lPadCenter = CGPointMake(x2Pt,yPt);
            
            // NSLog(@"self.rightPadView.center.x = %f  y = %f ",self.rightPadView.center.x,self.rightPadView.center.y);
            
            self.upperRightBar.center = rPadCenter;
            self.upperLeftBar.center = lPadCenter;
        }
        else
        {
            //NSLog(@"Left");
            
            CGFloat yPt = self.upperRightBar.center.y;
            CGFloat x1Pt = self.upperRightBar.center.x -4;
            CGFloat x2Pt = self.upperLeftBar.center.x -4;
            
            CGPoint rPadCenter = CGPointMake(x1Pt,yPt);
            CGPoint lPadCenter = CGPointMake(x2Pt,yPt);
            
            self.upperRightBar.center = rPadCenter;
            self.upperLeftBar.center = lPadCenter;
        }
        
        
        [_animator updateItemUsingCurrentState:_upperRightBar];
        [_animator updateItemUsingCurrentState:_upperLeftBar];
    }
    else
    {
        if (self.lowerRightBar.frame.origin.x > self.containerView.frame.size.width )
        {
            currentTouchLocation = previousTouchLocation;
        }
        
        if (self.lowerRightBar.frame.origin.x < 50 )
        {
            currentTouchLocation.x = (currentTouchLocation.x + 50);
        }
        
        
        if (currentTouchLocation.x > previousTouchLocation.x) {
            //NSLog(@"Right");
            
            CGFloat yPt = self.lowerRightBar.center.y;
            CGFloat x1Pt = self.lowerRightBar.center.x +7;
            CGFloat x2Pt = self.lowerLeftBar.center.x +7;
            
            
            CGPoint rPadCenter = CGPointMake(x1Pt,yPt);
            CGPoint lPadCenter = CGPointMake(x2Pt,yPt);
            
            // NSLog(@"self.rightPadView.center.x = %f  y = %f ",self.rightPadView.center.x,self.rightPadView.center.y);
            
            self.lowerRightBar.center = rPadCenter;
            self.lowerLeftBar.center = lPadCenter;
        }
        else
        {
            //NSLog(@"Left");
            
            CGFloat yPt = self.lowerRightBar.center.y;
            CGFloat x1Pt = self.lowerRightBar.center.x -4;
            CGFloat x2Pt = self.lowerLeftBar.center.x -4;
            
            CGPoint rPadCenter = CGPointMake(x1Pt,yPt);
            CGPoint lPadCenter = CGPointMake(x2Pt,yPt);
            
            self.lowerRightBar.center = rPadCenter;
            self.lowerLeftBar.center = lPadCenter;
        }
        
        
        [_animator updateItemUsingCurrentState:_lowerRightBar];
        [_animator updateItemUsingCurrentState:_lowerLeftBar];
    }
    
    
}

- (UIImage *) convertImageWithView:(UIView *)view
{
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, NO, 0.0);
    //UIGraphicsBeginImageContext(self.view.bounds.size);
    [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage * img = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return img;
}



#pragma mark - UICollisionBehavior Delegate method implementation

-(void)collisionBehavior:(UICollisionBehavior *)behavior beganContactForItem:(id<UIDynamicItem>)item withBoundaryIdentifier:(id<NSCopying>)identifier atPoint:(CGPoint)p{
    
}


-(void)collisionBehavior:(UICollisionBehavior *)behavior endedContactForItem:(id<UIDynamicItem>)item withBoundaryIdentifier:(id<NSCopying>)identifier{
    
    //self.orangeBall.backgroundColor = [UIColor orangeColor];
}


-(void)collisionBehavior:(UICollisionBehavior *)behavior beganContactForItem:(id<UIDynamicItem>)item1 withItem:(id<UIDynamicItem>)item2 atPoint:(CGPoint)p{
    
    //NSLog(@"%f",_lowerfirstBoundaryView.frame.origin.x);
}

#pragma mark - AVAudio Delegate method implementation

-(void)audioPlayerDidFinishPlaying:
(AVAudioPlayer *)player successfully:(BOOL)flag
{
    [_audioPlayer play];
}

-(void)audioPlayerDecodeErrorDidOccur:
(AVAudioPlayer *)player error:(NSError *)error
{
}

-(void)audioPlayerBeginInterruption:(AVAudioPlayer *)player
{
}

-(void)audioPlayerEndInterruption:(AVAudioPlayer *)player
{
}

- (IBAction)resumeButton:(id)sender {
    [self initBehaviors];
    _pauseView.hidden = YES;
    _transparentBG.hidden = YES;
}

- (IBAction)soundButton:(id)sender {
    
    if (_audioPlayer.playing) {
        [_audioPlayer stop];
        [self initBehaviors];
        
    }
    else
        [_audioPlayer play];
    
    [self initBehaviors];
    _pauseView.hidden = YES;
    _transparentBG.hidden = YES;
    
    
}

- (IBAction)menuButton:(id)sender {
    _pauseView.hidden = YES;
    _transparentBG.hidden = YES;
    [self.navigationController popToRootViewControllerAnimated:YES];
}


@end
