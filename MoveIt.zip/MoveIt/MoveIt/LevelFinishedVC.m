//
//  LevelFinishedVC.m
//  MoveIt
//
//  Created by Intelliswift on 18/07/14.
//  Copyright (c) 2014 Intelliswift. All rights reserved.
//

#import "LevelFinishedVC.h"
#import "HomeScreen.h"
#import "ExtremeLevelVC.h"

@interface LevelFinishedVC ()<UIAlertViewDelegate>
@property (strong ,nonatomic) HomeScreen *home;
@end

@implementation LevelFinishedVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}



- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    //_home = [[HomeScreen alloc] initWithNibName:@"HomeScreen" bundle:nil];
    //self.view.backgroundColor = [UIColor clearColor];
    
    self.navigationController.navigationBar.hidden = YES;
   // _containerView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.6];
    //[backView addSubview:_infoView];
    //[self.view addSubview:_];
   
    
}

-(void)viewWillDisappear:(BOOL)animated
{
    self.navigationController.navigationBar.hidden = NO;
    
}

-(void)viewWillAppear:(BOOL)animated
{
     _labelTimeTaken.text = _time;
    _bgView.image = _bgImageView;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)playAgainButton:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)nextLevelButton:(id)sender {
    
   
    
    if (_balls == 4) {
        [self.delegate ballCountValue:6];
        [self.navigationController popViewControllerAnimated:YES];
        
    }
    else
        if (_balls == 6) {
            [self.delegate ballCountValue:8];
            [self.navigationController popViewControllerAnimated:YES];
            
        }
   
    else
        if (_balls == 8)
        {
            
            ExtremeLevelVC *xtrmeVC = [[ExtremeLevelVC alloc] initWithNibName:@"ExtremeLevelVC" bundle:nil];
            [self.navigationController pushViewController:xtrmeVC animated:YES];
        }
    
     else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Congratulation" message:@"You have finished the game" delegate:self cancelButtonTitle:@"Thanks" otherButtonTitles:nil];
        [alert show];
    }
        
}

- (IBAction)menuButton:(id)sender {
    
    
    //self.modalPresentationStyle = UIModalPresentationCurrentContext;
    [self.navigationController popToRootViewControllerAnimated:YES];
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
}

@end
